//
//
// File generated from our OpenAPI spec
//
//

package stripe

const (
	apiVersion string = "2024-12-18.acacia"
)
